//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package org.kramerlab.teaching.ml.datasets;

public class NumericAttribute extends Attribute {
    public NumericAttribute(String name) {
        super(name);
    }

    @Override
    public boolean isNumeric() {
        return true;
    }
}
